export default {
    currentCategory:{},
    categories:[],
    products:[],
    cart:[],
    savedProduct:{}
}